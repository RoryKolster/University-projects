
# =============================================================================
# DMBA Project
# =============================================================================

# testing flag to indicate which instance set the code runs:
    # 1 for self generated instances
    # 2 for downloaded large instances
testing = 2
DP_num = 7 # Number of instances tested against Dynamic Programming


# importing packages
import numpy as np
import gurobipy as gp
import math
import scipy.stats as stats
import time
import matplotlib.pyplot as plt
np.random.seed(seed=1)

# =============================================================================
# Knapsack Binary Programming
# =============================================================================

def BKP(n, t, V, W):
    # Function that solves Knapsack problem as binary programming, using gurobi
    # package.
    
    # initiate timer
    start_time = time.time()
    
    # initiate gurobi model
    m = gp.Model("BinaryKP")
    # add binary selection variable
    x = m.addVars(n, vtype=gp.GRB.BINARY, name="x")
    # add capacity constraint
    m.addConstr(gp.quicksum(W[i]*x[i] for i in range(n)) <= t)
    # set objective function, maximising profit
    m.setObjective(gp.quicksum(V[i]*x[i] for i in range(n)), gp.GRB.MAXIMIZE)
    # suppress output messages
    m.setParam('OutputFlag',0)
    # optimize
    m.optimize()
    
    # end timer
    end_time = time.time()
    total_time = end_time - start_time
    
    return m, total_time


# =============================================================================
# Knapsack Dynamic Programming
# =============================================================================


def DPKP(n, t, V, W):
    # Function that solves instance of Knapsack, where we have
    # n items, capacity t, weights W, values V,
    # by the use of dynamic programming
    
    # Initiate timer
    start_time = time.time()
    
    # Create objective value matrix to fill in
    M = np.zeros((n+1,t+1))
    
    for i in range(0,n):
        for w in range(0,t+1):
            if W[i]> w:
                M[i+1,w] = M[i,w]
                
            else:
                M[i+1,w] = max(M[i,w], V[i] + M[i, int(np.floor(w - W[i]))])


    KP = []
    w = t

    for i in range(n, 0, -1):
        
        if M[i,int(w)] != M[i-1,int(w)]:
            KP.append(i)
            w -= W[i-1]
                
    KP.sort()
    
    # End timer
    end_time = time.time()
    total_time = end_time - start_time
         
    
    return KP, M, total_time

# =============================================================================
# Greedy Heuristic
# =============================================================================

def GHKP(n, t, V, W):
    # Function that attempts to solve the knapsack with input parameters, 
    # n items, t capacity, weights W and Value V,
    # by a greedy heuristic: keep adding items in order of value to weight
    # ratio until the knapsack is full
    
    # Initiate timer
    start_time = time.time()
    
    # Orders items in decreasing order for ratio of value to weight
    ratio = V/W
    argratio = np.argsort(ratio)
    argratio = argratio[::-1]
    
    
    KP = [] # create knapsack to add items to
    total_value = 0 # initiate current value
    remaining_weight = t # initiate current remaining weight
    for item in argratio:
        if W[item] <= remaining_weight: # add item if there is enough space
            KP.append(item)
            remaining_weight -= W[item] # update remaining weight
            total_value += V[item] # update current value
            
            
    KP.sort()
    
    # End timer
    end_time = time.time()
    total_time = end_time - start_time
            
    return KP, total_value, remaining_weight, total_time, argratio

# =============================================================================
# File reader
# =============================================================================

def read_knapsack_file(file_path):
    # Open the file for reading
    with open(file_path, 'r') as file:
        # Read the first line (number of items and total of the weights)
        first_line = file.readline().strip().split()
        num_items = int(first_line[0])
        total_weight = int(first_line[1])

        # Initialize lists for values and weights
        values = []
        weights = []

        # Read the subsequent lines (values and weights)
        for line in file:
            line_list = list(map(float, line.strip().split()))
            if len(line_list) > 2:
                break
            value, weight = map(float, line.strip().split())
            values.append(value)
            weights.append(weight)

    # Return the parsed data
    return num_items, total_weight, values, weights

# =============================================================================
# Improved Greedy Heuristic / Local Search
# =============================================================================


def GH_LS_KP(n, t, V, W):
    
    
    # Initiate timer
    start_time = time.time()
    
    # Orders items in decreasing order for ratio of value to weight
    ratio = V/W
    argratio = np.argsort(ratio)
    argratio = argratio[::-1]
    
    
    KP = [] # create knapsack to add items to
    total_value = 0 # initiate current value
    remaining_weight = t # initiate current remaining weight
    for item in argratio:
        if W[item] <= remaining_weight: # add item if there is enough space
            KP.append(item)
            remaining_weight -= W[item] # update remaining weight
            total_value += V[item] # update current value
            
    # Perform greedy heuristic on non-selected items
    i = 0
    while i < 2:
        current = KP[-1]
        current_ind = np.where(argratio == current)[0][0]
        target_weight = remaining_weight + W[current]
        # new_items = 
        new_items = argratio[current_ind+1:] # potential issue with this
        n_new = n - len(KP)
        V_new = V[new_items]
        W_new = W[new_items]
        
        # Select items that have a feasible weight
        W_new_feasible_ind = np.where(W_new <= target_weight)
        W_new_feasible = W_new[W_new_feasible_ind]
        # Order these feasible items in terms of value
        
        
        
        KP_new, total_value_new, remaining_weight_new, GH_total_time_new, argratio_new = GHKP(n_new, target_weight, V_new, W_new)
        if total_value_new > W[current]:
            break
        
        i += 1
        
    # Local search heuristic
    # i = 0
    # while i < len(KP):
    #     current = KP[-1]
    #     target_weight = remaining_weight + W[current]
    #     for j in range(1,4):
            
    
    KP.pop(-1)
    KP.append(KP_new)
    total_value = np.sum(V[KP])
    remaining_weight = t - np.sum(W[KP])
    
    
    # End timer
    end_time = time.time()
    total_time = end_time - start_time
            
    return KP, total_value, remaining_weight, total_time, argratio


# =============================================================================
# Testing
# =============================================================================


# Generated instances:
if testing == 1:
    num_instance = 20
    n_list = np.arange(0,10000,10000/num_instance)
    n_list += 10000/num_instance
    dict_instances_W = {}
    dict_instances_V = {}
    capacities = np.zeros(20)
    for i in range(num_instance):
        n = int(n_list[i])
        # x = np.arange(1,n+1)
        x = stats.randint(1,n).rvs(n)
        half_length = n_list[i]/100
        W_perturbs = stats.randint(-half_length, half_length).rvs(n)
        V_perturbs = stats.randint(-half_length, half_length).rvs(n)
        
        W = x + W_perturbs
        V = x + V_perturbs
        if np.min(W) <= 0:
            W += -np.min(W) + 1
            V += -np.min(V) + 1
        elif np.min(V) <= 0:
            W += -np.min(V) + 1
            V += -np.min(V) + 1
                    
        # capacity_coeff = stats.uniform(0,0.3).rvs(1)
        # t = int(np.floor(capacity_coeff * np.sum(W)))
        t = int(np.floor(n/2))
        
        inst_name = "Instance_"+str(i+1)+"_"+str(n)+"items_"+str(t)+"capacity"
        dict_instances_W[inst_name] = W
        dict_instances_V[inst_name] = V
        capacities[i] = t
        
    instances = np.arange(1,num_instance+1)
    instance_size = np.arange(1,num_instance+1)
    
    

    
    
# Downloaded instances:
# if testing == 2:
#     file_paths_small = ['f1_l-d_kp_10_269', 'f2_l-d_kp_20_878', 'f3_l-d_kp_4_20', 'f4_l-d_kp_4_11', 'f5_l-d_kp_15_375',
#               'f6_l-d_kp_10_60', 'f7_l-d_kp_7_50', 'f8_l-d_kp_23_10000', 'f9_l-d_kp_5_80', 'f10_l-d_kp_20_879']
if testing == 2:
    file_paths_large_correlated = ['knapPI_3_100_1000_1', 'knapPI_3_200_1000_1', 'knapPI_3_500_1000_1', 
                                'knapPI_3_1000_1000_1', 'knapPI_3_2000_1000_1', 'knapPI_3_5000_1000_1', 'knapPI_3_10000_1000_1']

    instances = np.arange(1,len(file_paths_large_correlated)+1)
    num_instance = len(instances)
    instance_size = np.arange(1,len(file_paths_large_correlated)+1)

times = np.zeros((3,np.shape(instances)[0]))
obj_vals = np.zeros((3,np.shape(instances)[0]))

# for file_path in file_paths_large_correlated:
# for i in range(len(file_paths_large_correlated)):


    
for i in range(num_instance):
    
    
    if testing == 1:
        n = int(n_list[i])
        t = int(capacities[i])
        inst_name = "Instance_"+str(i+1)+"_"+str(n)+"items_"+str(t)+"capacity"
        V = dict_instances_V[inst_name]
        W = dict_instances_W[inst_name]
        
    if testing == 2:
        n, t, values, weights = read_knapsack_file(file_paths_large_correlated[i])
        V = np.array(values)
        W = np.array(weights)
    
    instance_size[i] = n
    
    print("--------------------------------------------------------")
    if testing == 1:
        print("\nInstance: " + inst_name)
    elif testing == 2:
        print("\nInstance: " + file_paths_large_correlated[i])

    print("Number of items: " + str(n))
    print("Capacity: " + str(t))
    
    m, GB_total_time = BKP(n, t, V, W)
    times[0,i] = GB_total_time
    obj_vals[0,i] = m.ObjVal
    # for v in m.getVars():
    #     print('%s, %g' % (v.VarName, v.x))
    print(f"\nBinary Solver Obj: {m.ObjVal:g}")
    print("Elapsed time: " + str(GB_total_time))
    
    if testing == 1:
        if i <= DP_num:
            KP, M, DP_total_time = DPKP(n, t, V, W)
            times[1,i] = DP_total_time
            obj_vals[1,i] = M[-1,-1]
            print("\nDynamic Programming solution:")
            # print("\nOptimal item selection: ")
            # print(KP)
            print("with respective objective value: " + str(M[-1,-1]))
            print("Elapsed time: " + str(DP_total_time))
    
    
    if testing == 2:
        if i <= 4:
            KP, M, DP_total_time = DPKP(n, t, V, W)
            times[1,i] = DP_total_time
            obj_vals[1,i] = M[-1,-1]
            print("\nDynamic Programming solution:")
            # print("\nOptimal item selection: ")
            # print(KP)
            print("with respective objective value: " + str(M[-1,-1]))
            print("Elapsed time: " + str(DP_total_time))
    
    
    KP, total_value, remaining_weight, GH_total_time, argratio = GHKP(n, t, V, W)
    times[2,i] = GH_total_time
    obj_vals[2,i] = total_value
    print("\nGreedy Heuristic solution:")
    # print("\nOptimal item selection: ")
    # print(KP)
    print("with respective objective value: " + str(total_value))
    print("Elapsed time: " + str(GH_total_time))
    
    
# =============================================================================
# Plotting figures
# =============================================================================
percentage_obj = obj_vals[2,:] / obj_vals[0,:]
ones = np.ones(np.shape(percentage_obj))
if testing == 1:
    new_times = np.concatenate((ones,ones,percentage_obj), axis=0).reshape(3,20)
elif testing == 2:
    new_times = np.concatenate((ones,ones,percentage_obj), axis=0).reshape(3,7)


labels = ["Gurobi solver", "Dynamic Programming", "Greedy Heuristic"]
colours = ["b", "g", "r"]


if testing == 1:
    for i in range(2):
        plt.scatter(instance_size[:DP_num+1], times[i,:DP_num+1], label=labels[i], color=colours[i])
        plt.legend()
        plt.title("Time to solve for each instance (DP/GB)")
        plt.xlabel("Instance size")
        plt.ylabel("Time")
    plt.show()
    
if testing == 2:
    for i in range(2):
        plt.scatter(instance_size[:5], times[i,:5], label=labels[i], color=colours[i])
        plt.legend()
        plt.title("Time to solve for each instance (DP/GB)")
        plt.xlabel("Instance size")
        plt.ylabel("Time")
    plt.show()
    

for i in [0,2]:
    plt.scatter(instance_size, times[i,:], label=labels[i], color=colours[i])
    plt.legend()
    plt.title("Time to solve for each instance (GB/GH)")
    plt.xlabel("Instance size")
    plt.ylabel("Time")
    
plt.show()

for i in range(3):
    # if i == 3:
    #     plt.scatter(instance_size3, obj_vals[i,:])
    plt.scatter(instance_size, new_times[i,:], label=labels[i], color=colours[i])
    plt.legend()
    plt.title("Compared Objective values for each instance")
    plt.xlabel("Instance size")
    plt.ylabel("Percentage of Objective Value")
    
plt.show()
